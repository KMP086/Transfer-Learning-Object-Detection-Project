import os

model_file_path = "E:\\Programming\\Projects\\py_tensorflow\\Transfer Learning Object Detection Project\\Trained_Model\\checkpoints\\ssd_mobilenet_v2_fpnlite_320x320_coco17_tpu-8\\saved_model"
print(os.path.exists(model_file_path))        
print(model_file_path)

pip install opencv-python